from pathlib import Path
import csv
from datetime import datetime,timedelta,timezone
import json
from collections import Counter,defaultdict
from dateutil.parser import isoparse
import numpy as np
b=Path(__file__).parent
r=b/'20261127T075245Z_f64f306a96'
data=json.loads((b/'statistics.json').read_text(encoding='utf8'))
events=defaultdict(list)
streams=defaultdict(list)
cammeta=[]
for line in (b/'bag_records.txt').open(encoding='utf8'):
    if line.startswith('{'):
        continue
    rid,recv,topic,hd,detail=next(csv.reader([line]))
    recv=int(recv)
    if hd: streams[topic].append((recv,int(hd)))
    if topic=='/hardware_sync/camera_events':
        d=json.loads(detail)
        events[d['event_name']].append(d)
    elif topic=='/hardware_sync/camera_metadata':
        cammeta.append(json.loads(detail))
ns=lambda s:int(isoparse('2026-11-27T'+s+'+08:00').timestamp()*10**9)
t1=ns('15:56:20')
t2=ns('15:57:58')
tz=timezone(timedelta(hours=8))
def wall(ns):
    sec,frac=divmod(int(ns),10**9)
    return datetime.fromtimestamp(sec,tz).strftime('%Y-%m-%d %H:%M:%S')+f'.{frac:09d}+08:00'
out={}
for label,ts in [('timeshare_duplicate',t1),('imu_gap',t2)]:
    imgs=[]
    for k,(recv,h) in enumerate(streams['/hik_camera/image_timeshare']):
        if ts-300_000_000<recv<ts+1_000_000_000:
            a=cammeta[k]
            imgs.append({'frame':a['frame_num'],'device_raw':a['device_timestamp_raw'],'get':wall(a['host_after_get_ns']),'pub':wall(a['publish_done_ns']),'receipt':wall(recv),'image_header_ns':h})
    dd={'images':imgs,'gaps':{},'tums':{}}
    for name in ['/livox/lidar','/livox/imu']:
        ar=np.array(streams[name],dtype=np.int64)
        ar=ar[(ar[:,0]>ts-300_000_000)&(ar[:,0]<ts+1_000_000_000)]
        for k,nm in enumerate(('receive','header')):
            ix=np.argmax(np.diff(ar[:,k]))
            dd['gaps'][name+'_'+nm]=[wall(ar[ix,0]),wall(ar[ix+1,0]),(ar[ix+1,k]-ar[ix,k])/1e6]
    tum=np.loadtxt(r/'map/trajectory.tum')
    sel=(tum[:,0]>(ts/1e9-.3))&(tum[:,0]<(ts/1e9+1))
    a=tum[sel,0]
    dd['tums']={'max_pose_interval_ms':float(np.max(np.diff(a))*1000), 'poses':len(a)}
    out[label]=dd
# Estimate interval regularity from native camera ticks. Record event totals; exposure event absence around start may be subscription-related.
out['camera_event_counts']={name:len(vals) for name,vals in events.items()}
out['camera_runtime_mvs_events_lost_vs_recorded_count']=data['sensors']['camera']['events_written']-sum(out['camera_event_counts'].values())
out['camera_native_frame_interval_inferred_ms']=[float(x)/1e5 for x in np.percentile(np.diff([m['device_timestamp_raw'] for m in cammeta]),[0,50,95,99,100])]
# Exact event with largest archival pose gap.
tr=np.loadtxt(r/'map/trajectory.tum')
i=np.argmax(np.diff(tr[:,0]))
out['largest_pose_gap']={'start':wall(round(tr[i,0]*1e9)),'end':wall(round(tr[i+1,0]*1e9)),'ms':data['trajectory']['dt_ms']['maximum']}
(b/'event_analysis.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
for k,v in out.items():
    print(k, v if k not in ['timeshare_duplicate','imu_gap'] else {l:d for l,d in v.items() if l!='images'})
for a in out['timeshare_duplicate']['images']: print(a)
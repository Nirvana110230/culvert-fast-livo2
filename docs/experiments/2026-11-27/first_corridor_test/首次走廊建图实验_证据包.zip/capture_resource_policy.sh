set -eu
cd /home/orangepi/fast_livo2
echo '=== runtime memory pressure threshold ==='
nl -ba src/fast_livo/include/memory_diagnostics.h | sed -n '29,86p'
nl -ba runtime/session.py | sed -n '262,291p;293,325p'
echo '=== preserved previous-boot physical monitor evidence scope ==='
sudo -n systemd-analyze cat-config systemd/journald.conf | grep -E '^#?Storage=|^# /'
echo '=== previous and current startup snapshots (metadata only) ==='
sudo -n head -3 /var/log/dmesg.0
echo '=== target mount ==='
findmnt -no SOURCE,FSTYPE,OPTIONS -T /data/robot/maps/fast_livo2/runs

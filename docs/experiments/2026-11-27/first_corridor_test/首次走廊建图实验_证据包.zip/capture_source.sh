set -eu
cd /home/orangepi/fast_livo2
s=src/fast_livo/src/LIVMapper.cpp
v=src/fast_livo/src/vio.cpp
echo '=== deployment release identity ==='
cat records/stage_b1/deployment.json
for p in "$s" "$v" runtime/archive.py runtime/gravity.py runtime/map_store.py runtime/session.py camera/camera_sync.cpp; do sha256sum "$p"; done
echo '=== processing, native time, odometry stamp, camera offset ==='
nl -ba "$s" | sed -n '385,430p;450,530p;623,676p;938,963p;996,1052p;1113,1174p;1499,1519p'
echo '=== visual updates and logs ==='
nl -ba "$v" | sed -n '836,879p;1456,1550p;1650,1710p;1773,1870p;1885,1947p'
grep -RInE 'LRU budget exceeded|image_budget|kMaxImuQueue|timeshare_writes\\.csv' src/fast_livo/src src/fast_livo/include | head -80
echo '=== camera capture/header/restore ==='
nl -ba camera/camera_sync.cpp | sed -n '106,157p'
echo '=== resource sampling, odometry and gravity archive ==='
nl -ba runtime/session.py | sed -n '72,114p'
nl -ba runtime/archive.py | sed -n '22,50p;114,157p;310,334p'
nl -ba runtime/map_store.py | sed -n '268,272p'
grep -nE 'gravity|pose\(' runtime/gravity.py | head -55
echo '=== exact current hashes of this session and resolved configuration ==='
cd /data/robot/maps/fast_livo2/runs/corridor_20261127T075234Z_eiYOUs/20261127T075245Z_f64f306a96
sha256sum map/map_geometry.pcd map/map_rgb.pcd map/trajectory.tum resolved.yaml gravity_events.jsonl

from pathlib import Path
import sys, json, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import MultipleLocator

stage=Path(__file__).parent
run=stage/'20261127T075245Z_f64f306a96'
dest=Path(sys.argv[1])
s=json.loads((stage/'statistics.json').read_text(encoding='utf8'))
origin=s['session']['started_host_ns']
delta=s['processing_clock']['ros_minus_monotonic_s']['median']-origin/1e9
rr=[json.loads(x) for x in (run/'resources.jsonl').read_text().splitlines()]
el=[x['elapsed_s'] for x in rr]
size=1024**2
with (run/'Log/processing.csv').open() as fp:
    pd=np.array([[float(d[k]) for k in ['ros_s','processing_ms','cycle_ms']] for d in csv.DictReader(fp)])
with (run/'Log/visual_lru.csv').open() as fp:
    vd=np.array([[float(d[k]) for k in ['monotonic_s','image_bytes','protected_bytes','rss_bytes']] for d in csv.DictReader(fp)])
tum=np.loadtxt(run/'map/trajectory.tum')
from decimal import Decimal
t0=float(Decimal((run/'map/trajectory.tum').read_text().split()[0])-Decimal(origin)/Decimal(1e9))
moving=(t0+157.4,t0+578.91)
plt.rcParams['font.family']='Microsoft YaHei'
plt.rcParams['axes.unicode_minus']=False
plt.rcParams['axes.spines.top']=False
plt.rcParams['figure.facecolor']='white'
fig,ax=plt.subplots(4,1,figsize=(11,8.8),sharex=True,layout='constrained')
blue='#1B5387'
green='#26795F'
purple='#7D5395'
amber='#AB6723'
x_end=s['session']['elapsed_s']
for a in ax:
    a.axvspan(*moving,color='#E7F2EC',zorder=0)
    a.axvspan(t0+s['trajectory']['elapsed_s'],x_end,color='#F1EBF4',zorder=0)
    a.grid(axis='y',alpha=.24)
    a.xaxis.set_major_locator(MultipleLocator(60))
    a.set_xlim(0,735)

ax[0].plot(el,[a['process_rss_bytes'].get('algorithm',float('nan'))/size for a in rr],c=blue,lw=1.6,label='算法 RSS（会话）')
ax[0].plot(vd[:,0]+delta,vd[:,1]/size,c=green,lw=1.25,label='图像缓存')
ax[0].plot(vd[:,0]+delta,vd[:,2]/size,c=purple,lw=1.1,label='受保护图像')
ax[0].set_ylabel('MiB')
ax[0].legend(ncol=3,loc='upper left',frameon=False,fontsize=9)

ax[1].plot(el,[a['mem_available_bytes']/1024**3 for a in rr],c=blue,label='系统可用内存')
ax[1].set_ylabel('可用内存（GiB）',color=blue)
disk=ax[1].twinx()
disk.plot(el,[a['disk_free_bytes']/1024**3 for a in rr],c=amber,label='NVMe 可用空间')
disk.set_ylabel('NVMe 余量（GiB）',color=amber)
ax[1].tick_params(axis='y',colors=blue)
disk.tick_params(axis='y',colors=amber)

ax[2].plot(pd[:,0]-origin/1e9,pd[:,2],c=purple,alpha=.6,lw=.7,label='循环执行')
ax[2].plot(pd[:,0]-origin/1e9,pd[:,1],c=blue,lw=.72,alpha=.82,label='同步后处理')
ax[2].axhline(100,c='#974633',lw=.85,ls='--',label='100 ms 参考线')
ax[2].set_ylabel('处理耗时（ms）')
ax[2].legend(ncol=3,loc='upper left',frameon=False,fontsize=9)

ax[3].plot(tum[1:,0]-origin/1e9,np.diff(tum[:,0])*1000,c=blue,lw=.6,label='归档位姿间隔')
ax[3].axvline(214.60,c='#974633',lw=.9,ls='--')
ax[3].annotate('15:56:20  位姿间隔 281 ms',xy=(214.60,281),xytext=(245,246),
               color='#974633',fontsize=9,arrowprops={'arrowstyle':'-','color':'#974633'})
ax[3].set_ylabel('位姿间隔（ms）')
ax[3].set_xlabel('自现场会话开始的时间（秒）')
fig.suptitle('FAST-LIVO2 B1 首次走廊建图  |  2026-11-27',fontsize=16,weight='bold')
ax[0].set_title('绿色底纹为轨迹推定移动段，紫色底纹为最后位姿至会话结束。',loc='left',fontsize=10,pad=12)
fig.savefig(dest/'首次走廊建图实验_资源与时序.png',dpi=165)

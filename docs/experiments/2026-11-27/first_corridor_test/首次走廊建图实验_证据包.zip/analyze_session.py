from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
import csv
import json
from pathlib import Path
import re
from decimal import Decimal
import hashlib
import numpy as np
import yaml

base = Path(__file__).parent
run = base / '20261127T075245Z_f64f306a96'
tz = timezone(timedelta(hours=8))
MIB, GIB = 1024**2, 1024**3
phases = ['bringup','initial_static','movement','ending_static','stop_archive']

def round_floats(obj):
    if isinstance(obj, dict):
        return {str(k):round_floats(v) for k,v in obj.items()}
    if isinstance(obj, (list,tuple,np.ndarray)):
        return [round_floats(v) for v in obj]
    if isinstance(obj,np.bool_):
        return bool(obj)
    if isinstance(obj,np.integer):
        return int(obj)
    if isinstance(obj,(float,np.floating)):
        return round(float(obj),9)
    return obj

def stats(a):
    a = np.asarray(a)
    if not len(a):
        return {'n':0}
    q = np.percentile(a, [50,95,99])
    return dict(n=len(a), minimum=float(a.min()), mean=float(a.mean()), median=q[0], p95=q[1],p99=q[2],maximum=float(a.max()))

def load(path):
    return json.loads((run/path).read_text(encoding='utf8'))

def read_csv(path, types):
    with (run/path).open(encoding='utf8',newline='') as stream:
        r=csv.reader(stream)
        header=next(r)
        result=[]
        for row in r:
            if path=='sensors/camera/frames.csv' and len(row)==len(header)-1:
                row.insert(header.index('sdk_host_timestamp_raw'),'')
            assert len(row)==len(header),path
            record=dict(zip(header,row))
            result.append(tuple(t(record[k]) for k,t in types.items()))
        return np.array(result,dtype=list(types.items()))

def wall(ns):
    sec,frac=divmod(int(ns),10**9)
    return datetime.fromtimestamp(sec,tz).strftime('%Y-%m-%d %H:%M:%S')+f'.{frac:09d}+08:00'

tumfile = run/'map/trajectory.tum'
tumrows = [s.split() for s in tumfile.read_text().splitlines() if s.strip() and not s.startswith('#')]
assert all(len(row)==8 for row in tumrows)
tum_ns = np.array([int(Decimal(row[0])*10**9) for row in tumrows], dtype=np.int64)
pose = np.array([row[1:] for row in tumrows],dtype=np.float64)
assert np.isfinite(pose).all() and np.all(np.diff(tum_ns)>0)
p = pose[:,:3]
q = pose[:,3:]
t = (tum_ns-tum_ns[0])/1e9
move0,move1 = [int(tum_ns[0])+int(x*1e9) for x in [157.4,578.91]]
bound = [int(tum_ns[0]),move0,move1,int(tum_ns[-1])+1]
phase_of = lambda ns: np.searchsorted(bound, ns, side='right')
session=load('session.json')
proc=load('processes.json')
origin=session['started_host_ns']
assert all(v['boot_id']==(base/'boot_id.txt').read_text().strip() for v in proc.values())
def sample_mib(stat):
    return stats(np.array(stat)/MIB)

def length(pos):
    return np.linalg.norm(np.diff(pos,axis=0),axis=1).sum()
def qmean(quats):
    e,v=np.linalg.eigh(quats.T@quats)
    a = v[:,-1]
    return a if a[-1] >= 0 else -a

def angle(qa,qb):
    return np.degrees(2*np.arccos(np.clip(abs(np.asarray(qa)@qb),0,1)))

def stop_quant(a,b):
    ids=(t>=a)&(t<=b)
    pp=p[ids]
    qq=q[ids]
    center=pp.mean(axis=0)
    qa=qmean(qq)
    norm=np.linalg.norm(pp-center,axis=1)
    return dict(n=len(pp), center_m=center, qmean_xyzw=qa, rms_mm=np.sqrt(np.mean(norm**2))*1000, p95_mm=np.quantile(norm,.95)*1000, max_mm=norm.max()*1000, net_mm=np.linalg.norm(pp[-1]-pp[0])*1000, orientation_rms_deg=np.sqrt(np.mean(angle(qq,qa)**2)))
before,after = stop_quant(10,150),stop_quant(585,t[-1])
mp=p[(t>=157.4)&(t<=578.91)]
def resample_len(step):
    grid=np.r_[np.arange(157.4,578.91,step),578.91]
    return length(np.stack([np.interp(grid,t,p[:,j]) for j in range(3)],axis=1))
trajectory = dict(sha256=hashlib.sha256(tumfile.read_bytes()).hexdigest(), poses=len(t), elapsed_s=float(t[-1]), first=wall(tum_ns[0]),last=wall(tum_ns[-1]), mean_hz=(len(t)-1)/t[-1], dt_ms=stats(np.diff(tum_ns)/1e6),
  quaternion_max_unit_error=np.max(np.abs(np.linalg.norm(q,axis=1)-1)), full_3d_m=length(p),full_xy_m=length(p[:,:2]), movement_3d_m=length(mp), movement_resample_0_5s_m=resample_len(.5), movement_resample_1s_m=resample_len(1),
  movement_mean_speed_1s_m_s=resample_len(1)/(578.91-157.4), first_last_3d_m=np.linalg.norm(p[-1]-p[0]), static_centroid_delta_m=after['center_m']-before['center_m'], static_centroid_gap_m=np.linalg.norm(after['center_m']-before['center_m']), static_heading_3d_deg=angle(after['qmean_xyzw'],before['qmean_xyzw']), z_min_max_m=[p[:,2].min(),p[:,2].max()], initial_static=before, ending_static=after)

processing=read_csv('Log/processing.csv', {x:float for x in ['wall_s','ros_s','scan_begin_s','scan_end_s','state_s','processing_ms','cycle_ms','frames','lidar_queue','imu_queue','image_queue','lidar_rx','imu_rx','image_rx','vio_frames','visual_update_frames','visual_update_steps','synced']})
p_ns=np.rint(processing['ros_s']*1e9).astype('int64')
# time.time_ns / monotonic pairs also available independently in camera CSV.
offset = np.median(processing['ros_s']-processing['wall_s'])
p_phase=phase_of(p_ns)
processing_stats = {}
for k, pr in [('all',processing)]+[(name,processing[p_phase==i]) for i,name in enumerate(phases)]:
    processing_stats[k] = dict(rows=len(pr))
    for c in ['processing_ms','cycle_ms','lidar_queue','imu_queue','image_queue']:
        processing_stats[k][c] = stats(pr[c])
        if c.endswith('_ms'):
            sel=pr[pr[c]>100]
            processing_stats[k][c]['above_100_count']=len(sel)
            processing_stats[k][c]['above_100_events']=[{'time':wall(np.rint(row['ros_s']*1e9)), 'ms':row[c], 'movement_relative_to_first_pose_s':row['ros_s']-tum_ns[0]/1e9,'queues':[row[x] for x in ['lidar_queue','imu_queue','image_queue']]} for row in sel]
last_processing={k:processing[k][-1] for k in processing.dtype.names}
processing_clock=dict(sample_cadence_ms=stats(np.diff(processing['wall_s'])*1000), ros_minus_monotonic_s=stats(processing['ros_s']-processing['wall_s']), ros_minus_state_s=stats(processing['ros_s']-processing['state_s']), state_advancing=bool(np.all(np.diff(processing['state_s'])>0)))
resources = [json.loads(s) for s in (run/'resources.jsonl').read_text().splitlines()]
rss={x: np.array([row['process_rss_bytes'].get(x,np.nan) for row in resources], dtype=float) for x in ['algorithm','archive','camera','driver']}
rr=np.array([row['host_ns'] for row in resources],dtype=np.int64)
r_phase=phase_of(rr)
r_elapsed=np.array([row['elapsed_s'] for row in resources])
r_mem=np.array([row['mem_available_bytes'] for row in resources])
r_disk=np.array([row['disk_free_bytes'] for row in resources])
resource_stats={}
def slope(x,y):
    if len(x)<2:
        return None
    return np.polyfit(x-x[0],y,1)[0]
for name,chosen in [('all', np.ones(len(rr),dtype=bool))]+[(name,r_phase==i) for i,name in enumerate(phases)]:
    keep=chosen & np.isfinite(rss['algorithm'])
    alg_vals=rss['algorithm'][keep]/MIB
    time=r_elapsed[keep]
    ds=r_disk[chosen]/MIB
    tt=r_elapsed[chosen]
    resource_stats[name] = dict(records=int(sum(chosen)),elapsed_s=[tt[0],tt[-1]], mem_avail_GiB=stats(r_mem[chosen]/GIB), disk_free_GiB_start_end=ds[[0,-1]]/1024, filesystem_allocated_change_MiB=ds[0]-ds[-1], filesystem_allocated_rate_MiB_s=(ds[0]-ds[-1])/(tt[-1]-tt[0]) if len(tt)>1 else None, algorithm_RSS_MiB=stats(alg_vals), algorithm_RSS_MiB_start_end=alg_vals[[0,-1]] if len(alg_vals) else [], algorithm_RSS_slope_MiB_min=slope(time,alg_vals)*60 if len(time)>1 else None)
resource_peaks = {key: {'MiB': np.nanmax(v)/MIB, 'time':wall(rr[np.nanargmax(v)]),'session_elapsed_s':r_elapsed[np.nanargmax(v)]} for key,v in rss.items()}
rs=load('resources.json')
assert rs['samples']==len(resources) and rs['max_algorithm_rss_bytes']==np.nanmax(rss['algorithm']) and rs['min_available_bytes']==r_mem.min() and rs['min_disk_free_bytes']==r_disk.min()

lnames=(run/'Log/visual_lru.csv').read_text().splitlines()[0].split(',')
lru=read_csv('Log/visual_lru.csv',{k:float if k in ['monotonic_s','maintenance_ms'] else int for k in lnames})
lru_ns=np.rint((lru['monotonic_s']+offset)*1e9).astype('int64')
l_phase=phase_of(lru_ns)
lru_stats={}
for name,v in [('all',lru)]+[(name,lru[l_phase==i]) for i,name in enumerate(phases)]:
    lru_stats[name]={'rows':len(v)}
    if not len(v):
        continue
    for col in ['images','active_images','history_images','protected_images','blocked_points','borrowed_points','used_points','points','voxels','features','image_refs','maintenance_ms']:
        lru_stats[name][col] = dict(**stats(v[col]), first=v[col][0],last=v[col][-1])
    for col in ['patch_live_bytes','image_bytes','protected_bytes','rss_bytes','mem_available_bytes','system_shortfall_bytes']:
        lru_stats[name][col.removesuffix('_bytes')+'_MiB'] = dict(**sample_mib(v[col]),first=v[col][0]/MIB,last=v[col][-1]/MIB)
    for col in ['images_created','images_released','images_last_ref_freed','bytes_last_ref_freed','images_detached_external_ref','bytes_detached_external_ref','external_image_refs','points_evicted_total','features_evicted_total','pruned_observations_total','pressure_points_total']:
        lru_stats[name][col]=dict(first=v[col][0],last=v[col][-1],peak=v[col].max())
lru_first={k:lru[k][0] for k in lnames}
lru_last={k:lru[k][-1] for k in lnames}
assert np.all(np.diff(lru['frame'])>0)

camera_types={x:int for x in ['frame_num','device_timestamp_raw','host_after_get_ns','host_monotonic_after_get_ns','publish_done_ns','width','height','source_bytes','lost_packets']}
camera_types['conversion_ms']=float
camera=read_csv('sensors/camera/frames.csv',camera_types)
read=read_csv('sensors/camera/timeshare_reads.csv',{x:int for x in ['frame_num','device_timestamp_raw','host_after_get_ns','host_monotonic_after_get_ns','read_before_mono_ns','read_after_mono_ns','shared_stamp_ns','image_header_ns','offset_ns','fusion_candidate_ns']})
write=read_csv('sensors/timeshare_writes.csv',{x:int for x in ['scan_sequence','shared_stamp_ns','scan_first_point_ns','scan_last_point_ns','points','write_before_mono_ns','write_after_mono_ns']})
assert np.array_equal(camera['frame_num'],read['frame_num'])
assert np.array_equal(camera['host_after_get_ns'],read['host_after_get_ns'])
assert np.array_equal(camera['host_monotonic_after_get_ns'],read['host_monotonic_after_get_ns'])
write_by_stamp={int(r['shared_stamp_ns']):r for r in write}
pair_write_to_read = np.array([read_row['read_after_mono_ns']-write_by_stamp[int(read_row['shared_stamp_ns'])]['write_after_mono_ns'] for read_row in read])
camera_sync = dict(raw_frames_csv_header_missing_in_rows='sdk_host_timestamp_raw', frame_num_first_last=camera['frame_num'][[0,-1]], frames=len(camera), frame_number_gap_count=int(sum(np.diff(camera['frame_num'])!=1)), get_interval_ms=stats(np.diff(camera['host_monotonic_after_get_ns'])/1e6),
    get_interval_mono_ms_without_first_two=stats(np.diff(camera['host_monotonic_after_get_ns'])[2:]/1e6), conversion_ms=stats(camera['conversion_ms']),
    sdk_read_to_pub_ms=stats((camera['publish_done_ns']-camera['host_after_get_ns'])/1e6), host_minus_monotonic_s=stats((camera['host_after_get_ns']-camera['host_monotonic_after_get_ns'])/1e9), device_delta_raw_ticks=stats(np.diff(camera['device_timestamp_raw'])),
    hardware_clock_sliding_ratio_s_per_raw_tick=(camera['host_monotonic_after_get_ns'][-1]-camera['host_monotonic_after_get_ns'][0])/1e9/(camera['device_timestamp_raw'][-1]-camera['device_timestamp_raw'][0]),
    lost_packets_sum=int(camera['lost_packets'].sum()), write_rows=len(write), write_sequences_nonconsecutive=int(np.sum(np.diff(write['scan_sequence'])!=1)),
    share_stamp_matches_image_header=bool(np.array_equal(read['shared_stamp_ns'],read['image_header_ns'])),
    read_share_stamps_all_in_writes=True, writes_to_read_ms=stats(pair_write_to_read/1e6), constant_offset_ns=np.unique(read['offset_ns']),
    candidates_exact=bool(np.array_equal(read['image_header_ns']+read['offset_ns'],read['fusion_candidate_ns'])),
    duplicate_header_frame_numbers=camera['frame_num'][np.r_[False,np.diff(read['image_header_ns'])==0]],
    increasing_device_clock=bool(np.all(np.diff(camera['device_timestamp_raw'])>0)),
    about_header='SDK 每帧取帧记录与 timeshare 一一对应，绝对曝光相位未用外部时间参考验证。')

metadata = yaml.safe_load((base/'raw_bag/metadata.yaml').read_text())['rosbag2_bagfile_information']
entries=defaultdict(list)
aux=defaultdict(list)
shards=[]
with (base/'bag_records.txt').open(encoding='utf8',newline='') as f:
    for line in f:
        if line.startswith('{'):
            sh=json.loads(line)
            sh['counts']=Counter()
            sh['min_recv']=None
            sh['max_recv']=None
            shards.append(sh)
            continue
        rid,recv,topic,stamp,detail=next(csv.reader([line]))
        recv=int(recv)
        if stamp:
            stamp=int(stamp)
        else:
            stamp=-1
        entries[topic].append((recv,stamp,len(shards)-1,int(rid)))
        if detail:
            aux[topic].append(json.loads(detail))
        sh['counts'][topic]+=1
        sh['min_recv']=min(recv,sh['min_recv']) if sh['min_recv'] is not None else recv
        sh['max_recv']=max(recv,sh['max_recv']) if sh['max_recv'] is not None else recv
assert [sh['file'] for sh in shards]==metadata['relative_file_paths']
meta_files={v['path']:v for v in metadata['files']}
for sh in shards:
    n, first, last = sh['index_count_min_max']
    assert [sum(sh['counts'].values()), sh['min_recv'],sh['max_recv']]==[n,first,last]
    mf=meta_files[sh['file']]
    sh['index_matches_metadata']=n==mf['message_count'] and first==mf['starting_time']['nanoseconds_since_epoch'] and (last-first)==mf['duration']['nanoseconds']
first=min(sh['min_recv'] for sh in shards)
last=max(sh['max_recv'] for sh in shards)
assert first==metadata['starting_time']['nanoseconds_since_epoch']
assert last-first==metadata['duration']['nanoseconds']
expected={x['topic_metadata']['name']:x['message_count'] for x in metadata['topics_with_message_count']}
assert {k:len(v) for k,v in entries.items()}==expected
assert sum(expected.values())==metadata['message_count']
def gaps(a, column, threshold, dest):
    dt=np.diff(a[:,column])/1e6
    pl,pn=phase_of(a[:-1,0]),phase_of(a[1:,0])
    relevant=np.where(dt>threshold)[0]
    other=np.where(dt<=0)[0]
    def row(k):
        u,v=a[k:k+2]
        return {'interval_ms':dt[k], 'from_receipt':wall(u[0]),'to_receipt':wall(v[0]), 'from_receive_ns':u[0],'to_receive_ns':v[0],
         'from_header_ns':u[1],'to_header_ns':v[1],'phase_start':phases[pl[k]],'phase_end':phases[pn[k]],'shards':[int(u[2]),int(v[2])]}
    dest.extend((int(j),row(j)) for j in relevant)
    return {'interval_ms':stats(dt),'threshold_ms':threshold,'greater_count':len(relevant),'registered_nonpositive':len(other),
      'max_events':[row(j) for j in np.argsort(dt)[-5:][::-1]],
      'nonpositive_examples':[row(j) for j in other[:12]],
      'intra_phase':{k:dict(**stats(dt[(pl==i)&(pn==i)]),greater_count=int(sum((pl==i)&(pn==i)&(dt>threshold))),
                      nonpositive_count=int(sum((pl==i)&(pn==i)&(dt<=0)))) for i,k in enumerate(phases)},
      'cross_shard':stats(dt[a[1:,2]!=a[:-1,2]])}
topic_stats={}
gap_rows=[]
for topic,data in entries.items():
    a=np.array(data,dtype=np.int64)
    d=np.diff(a[:,0])
    record=dict(messages=len(a),first=wall(a[:,0].min()),last=wall(a[:,0].max()),first_header_ns=None,last_header_ns=None, average_per_bag_s=len(a)/((last-first)/1e9), counts_by_phase={k:int(sum(phase_of(a[:,0])==i)) for i,k in enumerate(phases)}, sqlite_insertion_receive_regressions=int(sum(d<0)))
    if topic in ['/livox/lidar','/livox/imu','/hik_camera/image_timeshare']:
        threshold=7.5 if topic=='/livox/imu' else 150
        b=a[np.argsort(a[:,0],kind='stable')]
        record.update(first_header_ns=a[0,1],last_header_ns=a[-1,1])
        for label,seq,col in [('receipt',b,0),('header',a,1)]:
            x=[]
            record[label]=gaps(seq,col,threshold,x)
            for _,row in x:
                gap_rows.append({'topic':topic,'time_basis':label,**row})
    topic_stats[topic]=record
b_img=np.array(entries['/hik_camera/image_timeshare'],dtype=np.int64)
b_imu=np.array(entries['/livox/imu'],dtype=np.int64)
b_lid=np.array(entries['/livox/lidar'],dtype=np.int64)
b_info=np.array(entries['/hik_camera/camera_info_timeshare'],dtype=np.int64)
b_meta=aux['/hardware_sync/camera_metadata']
imu_headers=np.sort(b_imu[:,1])
insert=np.searchsorted(imu_headers,read['fusion_candidate_ns'])
inside=(insert>0)&(insert<len(imu_headers))
ii=insert[inside]
wanted=read['fusion_candidate_ns'][inside]
camera_sync.update({
    'bag_headers_equal_camera_trace_by_order':np.array_equal(b_img[:,1],read['image_header_ns']),
    'camera_info_headers_equal_images_by_order':np.array_equal(b_img[:,1],b_info[:,1]),
    'bag_frame_numbers_equal_camera_trace_by_order':[m['frame_num'] for m in b_meta]==camera['frame_num'].tolist(),
    'all_bag_image_headers_present_in_lidar_writes':set(b_img[:,1])<=set(write_by_stamp),
    'bag_lidar_headers_present_in_lidar_writes_count':sum(x in write_by_stamp for x in b_lid[:,1]),
    'bag_camera_receive_minus_camera_get_ms':stats((b_img[:,0]-camera['host_after_get_ns'])/1e6),
    'imu_bracket_candidates':sum(inside),
    'imu_bracket_span_ms':stats((imu_headers[ii]-imu_headers[ii-1])/1e6),
    'imu_nearest_to_fusion_candidate_ms':stats(np.minimum(imu_headers[ii]-wanted,wanted-imu_headers[ii-1])/1e6),
    'unique_camera_fusion_candidates_matching_processing_state_within_1us':sum(np.abs(processing['state_s']-np.sort(read['fusion_candidate_ns'])[np.clip(np.searchsorted(np.sort(read['fusion_candidate_ns']),np.rint(processing['state_s']*1e9).astype('int64')-1000),0,len(read)-1)]/1e9)<1e-6),
})
# Focused values around ten-minute log intervals, the initial USB reset, and field relogin.
focus=[]
for label, iso in [('usb_reset','2026-11-27T15:52:59+08:00'),('cma_1','2026-11-27T15:53:01+08:00'),('cma_2','2026-11-27T15:53:50+08:00'),('cma_3','2026-11-27T15:54:40+08:00'),('ssh_reconnect','2026-11-27T16:03:44+08:00')]:
    e=int(datetime.fromisoformat(iso).timestamp())*10**9
    row={}
    for name,stream in [('lidar',b_lid),('imu',b_imu),('image',b_img)]:
        a=stream[(stream[:,0]>e-3_000_000_000)&(stream[:,0]<e+3_000_000_000)]
        row[name]={'messages':len(a),'max_receive_ms':float(np.max(np.diff(np.sort(a[:,0])))/1e6) if len(a)>1 else None,'max_header_ms':float(np.max(np.diff(a[:,1]))/1e6) if len(a)>1 else None}
    focus.append((label,iso,row))
total_size=sum(sh['size'] for sh in shards)
bag=dict(messages=sum(expected.values()),duration_s=(last-first)/1e9, first=wall(first),last=wall(last), shard_count=len(shards), size_bytes=total_size,size_GiB=total_size/GIB,
  allocated_bytes=sum(sh['allocated'] for sh in shards), mean_file_size_over_recording_MiB_s=(total_size/MIB)/((last-first)/1e9),
  shards_matching_meta=sum(sh['index_matches_metadata'] for sh in shards), shard_receipt_overlap_ns=[sh['min_recv']-prior['max_recv'] for prior,sh in zip(shards,shards[1:]) if sh['min_recv']<=prior['max_recv']],
  topics=topic_stats, focus_windows_pm_3s=focus)

algorithm_notes = []
for f in ['algorithm.log.1','algorithm.log']:
    for n,line in enumerate((run/f).read_text(errors='replace').splitlines(),1):
        if re.search(r'\[(WARN|ERROR|FATAL)\]|Throw one image|Input queues stalled|LRU budget exceeded|No [Vv]isual',line):
            algorithm_notes.append({'file':f,'line_no':n,'line':line})
archive=load('map/manifest.json')
rg=np.asarray(archive['transform']['R_GC'])
gravity=np.asarray(archive['transform']['gravity_camera_init_m_s2'])
g=rg@gravity
assert archive['counts']['poses']==len(t) and archive['files']['trajectory.tum']['sha256']==trajectory['sha256']
assert load('Log/input_counters.json')==session['mapper_counters']
sensor=dict(radar_start=load('sensors/radar_start.json'),radar_idle=load('sensors/radar_standby.json'),radar_idle_wire=load('sensors/radar_idle_packets.json'),camera=load('sensors/camera/driver_summary.json'),camera_usb=load('sensors/camera/usb_stats.json'),camera_settings={k:{p:load(f'sensors/camera/parameters.{k}.json')['parameters'][p] for p in ['TriggerMode','TriggerSelector','TriggerSource','AcquisitionFrameRateEnable','UserSetSelector','UserSetDefault','ExposureAuto','ExposureTime']} for k in ['before','active','after']}, camera_time_sync=camera_sync)
report=dict(session=session,field_boot_id=(base/'boot_id.txt').read_text().strip(),
  identity=load('algorithm_identity.json'),parameters=load('parameters_manifest.json'),
  phase_utc8={k: v for k,v in zip(phases+['ended'],map(wall,[origin,*bound,session['ended_host_ns']]))},
  process_utc8={k:dict(pid=v['pid'],start=wall(v['started_host_ns']),end=wall(v['exited_host_ns']),returncode=v['returncode'],forced=v['forced']) for k,v in proc.items()},
  processing=processing_stats,processing_clock=processing_clock,last_processing_row=last_processing, algorithm_notes=algorithm_notes,
  resource_peaks=resource_peaks,resources=resource_stats,resources_summary=rs,lru=lru_stats,lru_first=lru_first,lru_last=lru_last,
  sensors=sensor,bag=bag,trajectory=trajectory,gravity={'source_m_s2':gravity,'mapped_m_s2':g,'rotation_det':np.linalg.det(rg),'rotation_orthogonality_max_error':np.max(abs(rg.T@rg-np.eye(3))), 'rotation_angle_deg':np.degrees(np.arccos(np.clip((np.trace(rg)-1)/2,-1,1))), 'tf_check':archive['tf_check']})
def save(name, obj):
    (base/name).write_text(json.dumps(round_floats(obj),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
save('statistics.json',report)
save('sqlite_shards.json',shards)
with (base/'input_gaps.csv').open('w',newline='',encoding='utf-8') as f:
    out=csv.DictWriter(f,fieldnames=gap_rows[0])
    out.writeheader()
    out.writerows(gap_rows)
print(f'session {session["elapsed_s"]:.3f}s; bag {bag["messages"]} messages, {bag["shards_matching_meta"]}/{bag["shard_count"]} shards metadata match; {len(gap_rows)} threshold exceedances')

"""Read local Windows PCD exports; assess selected patches in map_gravity."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

base=Path(__file__).parent
map_dir=Path(sys.argv[1])
session=base/'20261127T075245Z_f64f306a96'
manifest=json.loads((session/'map/manifest.json').read_text())
T=np.loadtxt(map_dir/'trajectory.tum')
times=T[:,0]-T[0,0]
rng=np.random.default_rng(20261127)

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):
            h.update(b)
    return h.hexdigest()

def inspect(name):
    p=map_dir/name
    with p.open('rb') as f:
        header={}
        for raw in f:
            line=raw.decode('ascii').strip()
            if line.startswith('# frame_id'):
                frame=line.split()[-1]
            if not line or line.startswith('#'):
                continue
            k,*v=line.split()
            header[k]=v
            if k=='DATA':
                break
        offset=f.tell()
    count=int(header['POINTS'][0])
    columns=len(header['FIELDS'])
    stride=columns*4
    assert header['SIZE']==['4']*columns and header['TYPE']==['F']*columns and header['COUNT']==['1']*columns and header['DATA']==['binary']
    assert count*stride+offset==p.stat().st_size and int(header['WIDTH'][0])*int(header['HEIGHT'][0])==count
    rows=np.memmap(p,dtype='<f4',mode='r',offset=offset,shape=(count,columns))
    bad=0
    lo=np.full(3,np.inf)
    hi=-lo
    for start in range(0,count,250000):
        xyz=rows[start:start+250000,:3]
        ok=np.isfinite(xyz).all(axis=1)
        bad+=int((~ok).sum())
        lo=np.minimum(lo,xyz[ok].min(axis=0))
        hi=np.maximum(hi,xyz[ok].max(axis=0))
    digest=sha(p)
    assert digest==manifest['files'][name]['sha256']
    return dict(file=name,fields=header['FIELDS'],points=count, file_bytes=p.stat().st_size,header_bytes=offset,record_bytes=stride,payload_bytes=count*stride,
                frame=frame,viewpoint=header['VIEWPOINT'],format=header['DATA'][0],nonfinite_xyz=bad,bounds_xyz_m=[lo.tolist(),hi.tolist()],sha256=digest),rows

geo,xyz=inspect('map_geometry.pcd')
rgb,_=inspect('map_rgb.pcd')
assert sha(map_dir/'trajectory.tum')==manifest['files']['trajectory.tum']['sha256']
data=xyz[:,:3]

def plane(p,kind):
    center=p.mean(axis=0)
    _,_,vh=np.linalg.svd(p-center,full_matrices=False)
    n=vh[-1]
    if kind=='floor' and n[2]<0:
        n=-n
    return n,n@center

def fitting(data, kind):
    threshold = 0.035 if kind=='floor' else 0.025
    if len(data)<350:
        return None
    sample=data[rng.choice(len(data),min(len(data),4000),replace=False)]
    tr=sample[rng.integers(len(sample),size=(450,3))]
    n=np.cross(tr[:,1]-tr[:,0],tr[:,2]-tr[:,0])
    norm=np.linalg.norm(n,axis=1)
    n=n[norm>0.025]/norm[norm>0.025,None]
    first=tr[norm>0.025,0]
    valid=np.abs(n[:,2])>=0.94 if kind=='floor' else np.abs(n[:,2])<0.2
    if not valid.any():
        return None
    n,first=n[valid],first[valid]
    ds=np.einsum('ij,ij->i',n,first)
    votes=np.sum(np.abs(sample@n.T-ds)<threshold,axis=0)
    win=np.argmax(votes)
    sel=np.abs(data@n[win]-ds[win])<threshold
    for _ in range(3):
        n,d=plane(data[sel],kind)
        sel=np.abs(data@n-d)<threshold
    err=data[sel]@n-d
    inliers=data[sel]
    return dict(normal=n.tolist(),d_m=float(d),candidates=len(data),inliers=len(inliers),support_ratio=float(sum(sel)/len(data)),
        min_inlier_xyz_m=inliers.min(axis=0).tolist(),max_inlier_xyz_m=inliers.max(axis=0).tolist(),rms_mm=float(1000*np.sqrt(np.mean(err**2))),
        p95_absolute_mm=float(np.quantile(np.abs(err),.95)*1000),angle_to_horizontal_plane_deg=float(np.degrees(np.arccos(abs(n[2])))),
        selection_distance_mm=threshold*1000)

def patch(sec):
    idx=np.argmin(abs(times-sec))
    center=T[idx,1:4]
    if sec==0:
        along=np.array([1.,0.])
    else:
        a,b=(np.argmin(abs(times-k)) for k in (sec-3,sec+3))
        along=T[b,1:3]-T[a,1:3]
        along/=np.linalg.norm(along)
    cross=np.array([-along[1],along[0]])
    mask=(np.abs(data[:,0]-center[0])<5)&(np.abs(data[:,1]-center[1])<5)&(data[:,2]>(center[2]-1.65))&(data[:,2]<(center[2]+2.3))
    raw=data[mask].astype(np.float64)
    delta=raw[:,:2]-center[:2]
    u=delta@along
    v=delta@cross
    fk=(abs(u)<=1.5)&(abs(v)<=0.8)&(raw[:,2]<center[2]-.15)
    floor=fitting(raw[fk],'floor')
    if floor:
        n=np.array(floor['normal'])
        z=(floor['d_m']-center[:2]@n[:2])/n[2]
        floor.update(at_center_z_m=float(z),sensor_center_above_plane_m=float(center[2]-z))
    wk=(abs(u)<=2.0)&(raw[:,2]>((z if floor else center[2]-.5)+.25))&(raw[:,2]<((z if floor else center[2]-.5)+1.9))
    results={'time_s':sec,'center_xyz_m':center.tolist(),'tangent_xy':along.tolist(),'floor':floor}
    for label,s in [('wall_left',1),('wall_right',-1)]:
        sel=wk&(s*v>=.55)&(s*v<=3.3)
        results[label]=fitting(raw[sel],'wall')
    return results

patches=[patch(t) for t in [0,235,272,340,470]]
result=dict(geometry=geo,rgb=rgb,trajectory_windows_manifest_sha256=sha(map_dir/'trajectory.tum'),sampled_plane_method='以轨迹点为中心，地面取沿线 ±1.5 m、横向 ±0.8 m 和传感器下方区域；墙取沿线 ±2 m、横距 0.55–3.3 m 和地面上方 0.25–1.9 m。固定种子、最大 4000 候选点建立平面假设，用局部全量点重拟合。地面/墙面 inlier 门限 35/25 mm。',patches=patches)
(base/'map_check.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print('Verified local geometry/RGB/TUM SHA256 and binary formats; five plane patches written.')

set -eu
F=/data/robot/maps/fast_livo2/runs/corridor_20261127T075234Z_eiYOUs
R=20261127T075245Z_f64f306a96
cd "$F"
find "$R" -type f | sort >&2
tar -czf - boot_id.txt field_events.log start.log recorder.log raw_bag/metadata.yaml \
  --exclude='*/genicam.xml' --exclude='*/MvSdkLog/*' --exclude='*.pcd' --exclude='*.png' --exclude='*/algorithm_process.json' --exclude='*/roslog/*' "$R"
set -eu
cd /home/orangepi/fast_livo2
echo '=== package-level Livox timeshare ==='
nl -ba src/livox_ros_driver2/src/comm/pub_handler.cpp | sed -n '98,122p;260,276p'
echo '=== current B1 LRU policy ==='
nl -ba src/fast_livo/include/visual_map_lru.h | sed -n '1,260p'
find src/fast_livo -iname '*memory*' -o -iname '*lru*'
grep -RInE 'lru_options|shortfall\(' src/fast_livo/{include,src} | head -70
echo '=== camera SDK targeted startup/stop excerpts (serial redacted) ==='
run=/data/robot/maps/fast_livo2/runs/corridor_20261127T075234Z_eiYOUs/20261127T075245Z_f64f306a96
grep -Ei 'Open device success|Get cti version|TimestampTickFrequency|GetImageBuffer|StopGrabbing|CloseDevice|StartGrabbing|reset' "$run"/MvSdkLog/*.log | sed -E 's/DB[0-9]{7,}/[camera-serial]/g; s/[[:xdigit:]]{2}(:[[:xdigit:]]{2}){5}/[mac]/g'

from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from datetime import datetime,timezone,timedelta
import hashlib
import json
import re
import sys
from decimal import Decimal
import numpy as np

b=Path(__file__).parent
r=b/'20261127T075245Z_f64f306a96'
dest=Path(sys.argv[1])
def read(name): return json.loads((b/name).read_text(encoding='utf8'))
s=read('statistics.json')
s['schema']='fast_livo2.first_corridor_board_review.v1'
s['release']={'label':'stage-b1-20261127','commit':'082098ff69052e02397807094cdfa9c4a412b9e7','elf_sha256_confirmed_in_run':s['identity']['sha256'],'resolved_yaml_sha256':hashlib.sha256((r/'resolved.yaml').read_bytes()).hexdigest()}
s['field_context']={'timezone':'Asia/Shanghai','platform':'人工推动的四轮小推车与收纳箱','power':'主控使用充电宝标称 5 V / 3 A，雷达与同步器经 DP100 供电','wifi_field_ssh_timeout_reported':True,'maintenance_usb_disconnected_during_field':True,'start_and_return_pids_identical_from_field_snapshots':True}
s['power_review']={'pass_this_load':True,'immediate_replacement_supported_by_evidence':False,'input_voltage_or_power_measured':False,'verified_input_undervoltage_telemetry':False,
  'current_adapter_boot_id':'e602edf5-1e54-4d7f-9d3c-efe34cd82c49','historical_journal_exists':False,
  'historical_rsyslog_and_wtmp_available':True,'historical_wtmp_pre_sync_boot_local':'15:17:00','chrony_step_time_local':'15:44:31','chrony_step_seconds':1632.168584,'historical_boot_estimated_local':'15:44:02','normal_shutdown_wtmp_local':'16:34:54',
  'kernel_cma_failures_local':['15:53:01','15:53:50','15:54:40'],'kernel_cma_pages':[512,1024,1024],
  'camera_usb_reset_local':'15:52:59','camera_usb_reset_during_active_capture_observed':False,
  'prior_powerbank_baseline':{'date':'2026-11-26','sample_count':25,'duration_s':243.11,'radar_state':'IDLE','source':'docs/hardware_health/2026-11-26/USB供电快检_105104.txt'},
  'historical_sysstat':{
    'sampled_end_utc8':['16:00:26','16:10:26'],'interval_s':600,'all_cpu_non_idle_pct':[26.31,24.88],'iowait_pct':[.12,.05],
    'nvme_write_KiB_s':[30180.57,20721.60],'swap_used_KiB':[512,512],'swap_total_KiB':8176804,'capture_temperature_timeseries_available':False},
  'soc_field_snapshots_C_from_web':[40,58],
  'unknown_electrical_metrics':['board_input_voltage','minimum_transient_voltage','peak_current','power','cable_voltage_drop','multiport_power_division','long_duration_headroom']}
manifest=json.loads((r/'map/manifest.json').read_text(encoding='utf8'))
s['gravity']['tf_check']=manifest['tf_check']
rot=np.asarray(manifest['transform']['R_GC'])
s['gravity']['rotation_orthogonality_max_error']=float(abs(rot.T@rot-np.eye(3)).max())
s['map_integrity']=read('map_check.json')
s['input_events']=read('event_analysis.json')
s['methods']={'processing_scope':'成功同步循环约 1 s 采样，1 个图像融合时刻可能包含 LIO 与 VIO 两个循环。','bag_scope':'全部消息索引与核心消息头，三路诊断 JSON，未验证全部图像和点云载荷。','bag_gap_thresholds_ms':{'lidar':150,'imu':7.5,'image':150},'lru_historical_fixed_limit_MiB':512,
  'b1_system_mem_reserve_GiB':s['resources_summary']['latest']['mem_total_bytes']/8/1024**3,
  'absolute_exposure_alignment_verified':False,'t_start_relative_to_first_pose_s':157.4,'t_stop_relative_to_first_pose_s':578.91,'pcd_metrics_scope':'原文件完整性已验，地面/墙体为同一地图内局部拟合。'}
first_last=[x.split()[0] for x in (r/'map/trajectory.tum').read_text().splitlines()]
def wall_ns(sec_str):
    ns=int(Decimal(sec_str)*10**9)
    sec,frac=divmod(ns,10**9)
    return datetime.fromtimestamp(sec,timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')+f'.{frac:09d}+08:00'
ns=[int(Decimal(v)*10**9) for v in first_last]
i=np.argmax(np.diff(ns))
s['input_events']['largest_pose_gap']['start']=wall_ns(first_last[i])
s['input_events']['largest_pose_gap']['end']=wall_ns(first_last[i+1])
q=np.loadtxt(r/'map/trajectory.tum',usecols=(4,5,6,7))
s['trajectory']['quaternion_max_unit_error']=float(np.max(abs(np.linalg.norm(q,axis=1)-1)))
s['identity_check']={'map_board_sha256_equals_manifest':{},'map_board_sha256_equals_windows':{}}
source=(b/'source_evidence.txt').read_text(encoding='utf8')
for key,filename in [('geometry','map_geometry.pcd'),('rgb','map_rgb.pcd'),('trajectory','trajectory.tum')]:
    expected=s['trajectory']['sha256'] if key=='trajectory' else s['map_integrity'][key]['sha256']
    assert re.search(rf'(?m)^{expected}  map/{re.escape(filename)}$',source), filename
    for k in s['identity_check']: s['identity_check'][k][filename]=True
names=['bag_extract.py','run_read.py','analyze_session.py','analyze_map.py','analyze_events.py','plot_session.py',
       'pack_evidence.py','capture_session.sh','capture_system.sh','capture_source.sh','capture_supplement.sh','capture_policy.sh','capture_resource_policy.sh',
       'system_evidence.txt','source_evidence.txt','supplement.txt','policy_excerpt.txt','resource_policy.txt',
       'boot_id.txt','field_events.log','start.log','recorder.log','raw_bag/metadata.yaml','bag_records.txt','sqlite_shards.json','input_gaps.csv']
for f in r.rglob('*'):
    if f.is_file() and f.name not in {'genicam.xml'} and 'MvSdkLog' not in f.parts:
        names.append(f.relative_to(b).as_posix())
assert len(names)==len(set(names))
archive=dest/'首次走廊建图实验_证据包.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as z:
    catalog=[]
    for n in sorted(names):
        p=b/n
        buf=p.read_bytes()
        z.writestr(n,buf)
        catalog.append(f'{hashlib.sha256(buf).hexdigest()}  {n}')
    z.writestr('SHA256SUMS.txt','\n'.join(catalog)+'\n')
with ZipFile(archive) as z:
    assert z.testzip() is None
    for a in z.read('SHA256SUMS.txt').decode().splitlines():
        h,n=a.split('  ',1)
        assert hashlib.sha256(z.read(n)).hexdigest()==h,n
s['evidence_zip']={'file':archive.name,'verified_members':len(names),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(dest/'首次走廊建图实验_关键指标.json').write_text(json.dumps(s,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
print(s['evidence_zip'])
print(s['gravity'])

set -eu
cd /home/orangepi/fast_livo2
d=src/livox_ros_driver2/src
echo '=== Livox SDK packet time base selected by driver ==='
grep -nE 'timestamp|time_type|sync|system_clock|steady_clock' "$d/comm/pub_handler.cpp" | head -85
nl -ba "$d/lddc.cpp" | sed -n '227,244p;360,389p;488,503p'
echo '=== camera and visual budgets source ==='
grep -n '^  RollingCsv csv\|csv.row()' camera/camera_sync.cpp
grep -RInE '512ULL|512 *\*|536870912|image_max_bytes|memory_image|protected active images|budget exceeded|protected_images|image_bytes_max|image_cap' src/fast_livo/{include,src} | head -65
grep -nE 'transform.pose|pose has|last_stamp' runtime/archive.py
grep -nE 'gravity|def pose' runtime/gravity.py | head -45
echo '=== filter persisted kernel evidence from board boot logs ==='
sudo -n grep -anE 'Nov 27 16:34:.*(shutdown|poweroff|power-off|Power-Off|Power down|halt|unmount|Stopping|sync|watchdog)' /var/log/syslog | tail -40
echo '=== board boot hardware monitor headers and same-field-boot temperature rows ==='
grep -aEn 'Nov 27.*2026.*Orange Pi 5 Ultra|^15:17:0[0-9]:' /var/log/orangepi-hardware-monitor.log | tail -20
grep -E 'PACKAGE_VERSION|<version>' /opt/ros/humble/share/rosbag2_transport/{package.xml,cmake/rosbag2_transportConfig-version.cmake} | head -4

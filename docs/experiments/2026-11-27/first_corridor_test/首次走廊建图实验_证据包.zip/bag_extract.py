import ctypes as C
import ctypes.util
import csv
import json
import pathlib
import sqlite3
import struct
import sys
import yaml

root = pathlib.Path('/data/robot/maps/fast_livo2/runs/corridor_20261127T075234Z_eiYOUs/raw_bag')
meta = yaml.safe_load((root / 'metadata.yaml').read_text())['rosbag2_bagfile_information']
db = C.CDLL(ctypes.util.find_library('sqlite3'))
for name, args in {
    'open_v2': [C.c_char_p,C.POINTER(C.c_void_p),C.c_int,C.c_char_p],
    'close': [C.c_void_p],
    'blob_open': [C.c_void_p,C.c_char_p,C.c_char_p,C.c_char_p,C.c_int64,C.c_int,C.POINTER(C.c_void_p)],
    'blob_bytes': [C.c_void_p],
    'blob_read': [C.c_void_p,C.c_void_p,C.c_int,C.c_int],
    'blob_close': [C.c_void_p],
}.items():
    getattr(db, 'sqlite3_'+name).argtypes = args

def check(status):
    if status:
        raise RuntimeError(f'SQLite C API error {status}')

def prefix(conn, rowid, n=None):
    h = C.c_void_p()
    check(db.sqlite3_blob_open(conn,b'main',b'messages',b'data',rowid,0,C.byref(h)))
    try:
        size = db.sqlite3_blob_bytes(h)
        buf = C.create_string_buffer(min(size,n) if n is not None else size)
        check(db.sqlite3_blob_read(h,buf,len(buf),0))
        return buf.raw
    finally:
        check(db.sqlite3_blob_close(h))

def endian(head):
    if head[:2] == b'\0\1':
        return '<'
    if head[:2] == b'\0\0':
        return '>'
    raise ValueError(head.hex())

topics_with_header = {'/livox/lidar','/livox/imu','/hik_camera/image_timeshare','/hik_camera/camera_info_timeshare'}
small = {'/hardware_sync/camera_metadata','/hardware_sync/camera_clock','/hardware_sync/camera_events'}
paths = meta['relative_file_paths']
assert {p.name for p in root.glob('*.db3')} == set(paths)
for name in paths:
    p = root / name
    assert not any(pathlib.Path(str(p)+suffix).exists() for suffix in ('-wal','-journal'))
    uri = p.as_uri()+'?mode=ro&immutable=1'
    conn = C.c_void_p()
    check(db.sqlite3_open_v2(uri.encode(),C.byref(conn),0x1|0x40,None))
    try:
        with sqlite3.connect(uri,uri=True) as sql:
            topics = dict(sql.execute('select id,name from topics'))
            types = list(sql.execute('select name,type,serialization_format from topics'))
            bounds = sql.execute('select count(*),min(timestamp),max(timestamp) from messages indexed by timestamp_idx').fetchone()
            print(json.dumps({'file':name,'size':p.stat().st_size,'allocated':p.stat().st_blocks*512,'topics':types,'index_count_min_max':bounds,'page_size':sql.execute('pragma page_size').fetchone()[0]}), flush=True)
            c = csv.writer(sys.stdout, lineterminator='\n')
            for idx,recv,tid in sql.execute('select id,timestamp,topic_id from messages not indexed order by id'):
                topic = topics[tid]
                stamp = ''
                details = ''
                if topic in topics_with_header:
                    head = prefix(conn,idx,12)
                    sec, ns = struct.unpack_from(endian(head)+'iI',head,4)
                    assert ns < 10**9
                    stamp = sec * 10**9 + ns
                elif topic in small:
                    data = prefix(conn,idx)
                    n, = struct.unpack_from(endian(data)+'I',data,4)
                    details = data[8:8+n-1].decode()
                c.writerow((idx,recv,topic,stamp,details))
    finally:
        check(db.sqlite3_close(conn))
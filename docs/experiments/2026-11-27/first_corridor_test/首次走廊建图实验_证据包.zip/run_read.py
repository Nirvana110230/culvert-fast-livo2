from pathlib import Path
import subprocess
import sys

stage = Path(__file__).parent
ssh = ['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UpdateHostKeys=no','-o','HostKeyAlgorithms=ssh-ed25519','-o','ConnectTimeout=10','opiss-usb']
def capture(output, command, source=None):
    stdin = (stage / source).read_bytes() if source else None
    with (stage/output).open('wb') as dest:
        result = subprocess.run(ssh + [command], input=stdin, stdout=dest)
    result.check_returncode()
if __name__ == '__main__':
    capture(sys.argv[1],sys.argv[2],sys.argv[3] if len(sys.argv)>3 else None)
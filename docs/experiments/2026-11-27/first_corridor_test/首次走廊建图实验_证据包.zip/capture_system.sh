set -u
export LC_ALL=C TZ=Asia/Shanghai
echo '=== Strict USB identity and current boot (adapter) ==='
id -un; hostname; uname -mr; date --iso-8601=seconds; cat /proc/sys/kernel/random/boot_id
ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
F=/data/robot/maps/fast_livo2/runs/corridor_20261127T075234Z_eiYOUs
boot=$(tr -d -- '-\n' < "$F/boot_id.txt")
printf 'field boot: %s\n' "$boot"
sudo -n journalctl --list-boots --no-pager
sudo -n journalctl -b "$boot" -n 1 --no-pager; echo "historical journal rc=$?"
sudo -n ls -la /var/log/journal /run/log/journal /sys/fs/pstore
sudo -n ls -l /var/log/kern.log* /var/log/syslog* /var/log/dmesg* /var/log/sysstat/sa27 /var/log/orangepi-hardware-monitor.log
echo '=== wtmp historical and current boot boundary ==='
last -x -F --since '2026-11-27 15:10:00' --until '2026-11-27 17:06:30' | sed -E 's/10\.247\.78\.[0-9]+/[hotspot-client]/g'
echo '=== kern.log before SSH session setup plus acquisition to halt (local time) ==='
sudo -n awk '$1=="Nov" && $2==27 && $3>="15:40:00" && $3<"16:35:00"' /var/log/kern.log | sed -E 's/([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}/[mac]/g; s/DB[0-9]{7,}/[camera-serial]/g'
echo '=== syslog same historical window (kernel lines preserved above) ==='
sudo -n awk '$1=="Nov" && $2==27 && $3>="15:40:00" && $3<"16:35:00" && $5!="kernel:"' /var/log/syslog | sed -E 's/([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}/[mac]/g; s/DB[0-9]{7,}/[camera-serial]/g; s/10\.247\.78\.[0-9]+/[hotspot]/g'
echo '=== Nov 27 boot and shutdown lines from persistent kernel 15:17–15:40 ==='
sudo -n awk '$1=="Nov" && $2==27 && $3>="15:16:50" && $3<"15:40:00"' /var/log/kern.log | grep -Ei 'Linux version|Booting Linux|under.?volt|brown.?out|regulator|thermal|throttl|nvme|pcie|ext4|usb 2-1|link is|link up|link down|cma:|hardware error' | sed -E 's/([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}/[mac]/g; s/DB[0-9]{7,}/[camera-serial]/g'
echo '=== sysstat historical observations CPU, memory, swap, disk, network ==='
sar -u -r -S -W -d -n DEV,EDEV -f /var/log/sysstat/sa27 -s 15:40:00 -e 16:35:00
echo '=== board monitoring log session markers and any matching time rows ==='
grep -aEn 'Nov 27.*2026|^15:5[2-9]:|^16:0[0-5]:' /var/log/orangepi-hardware-monitor.log | awk '{ if (NF<18) print }' | head -100
echo '=== current-boot platform capability (not historical fault telemetry) ==='
for p in /sys/class/hwmon/*; do printf '%s ' "$p"; cat "$p/name"; ls "$p" | grep -E '^(in|curr|power|temp|pwm)[0-9]' | xargs; done
ls -A /sys/class/power_supply
for p in /sys/bus/iio/devices/iio:device*; do cat "$p/name"; ls "$p" | grep -E 'voltage|current' | xargs; done
for p in $(find /proc/device-tree -type d 2>/dev/null); do
  if [ -f "$p/regulator-name" ]; then
    n=$(tr -d '\0' < "$p/regulator-name")
    case "$n" in vcc5v0_sys|vcc5v0_usbdcin)
      printf '%s %s: ' "$p" "$n"; tr '\0' ' ' < "$p/compatible"; echo
    esac
  fi
done
find /proc/device-tree -name io-channels -print
for p in /sys/class/thermal/thermal_zone*; do
  printf '%s ' "$(cat "$p/type")"; for q in "$p"/trip_point_*_temp; do [ ! -e "$q" ] || printf '%s=%s/%s ' "$(basename "$q")" "$(cat "$q")" "$(cat "${q%_temp}_type")"; done; echo
done
findmnt -no SOURCE,FSTYPE,OPTIONS -T "$F"
